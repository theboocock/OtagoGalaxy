#!/bin/sh

./mergePc.py t2d.mds $HOME/t2d1/pheno/pheno.age.tfam $HOME/t2d1/eff/hm.gt.vcf > coEvolution.pheno.covariates.txt
